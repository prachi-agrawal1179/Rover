#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Joy
from geometry_msgs.msg import Vector3

s = Vector3()

def keys_cb(msg, servo_pub):
	
	if(msg.buttons[4]==1):
		s.x = msg.axes[1]*90
	if(msg.buttons[5]==1):	
		s.y = msg.axes[2]*90

	

	servo_pub.publish(s)

if __name__ == '__main__':
	rospy.init_node('JOYstick_servo')
	servo_pub = rospy.Publisher('servo_vel',Vector3, queue_size=10)
	rospy.Subscriber('joy',Joy, keys_cb,servo_pub)
	rospy.spin()
